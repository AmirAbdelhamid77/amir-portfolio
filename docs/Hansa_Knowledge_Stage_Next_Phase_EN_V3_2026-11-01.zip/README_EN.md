# Hansa Knowledge Stage — next-phase plan V3

Prepared 1 November 2026. Language: English. This delivery contains planning documents only; it does not implement, publish or deploy the proposed changes.

The next product direction is an **Intent-driven Interactive Knowledge Graph** within the existing Home journey: full-viewport Timeline, intentional Daily Dealer, a knowledge stage that adapts to the learner's task, and a concise closing.

| Read order | Document | Purpose |
|---|---|---|
| 1 | [NEXT_PHASE_PLAN_EN.md](NEXT_PHASE_PLAN_EN.md) | Current evidence, scope, priorities, milestones, affected modules, completion and future vision |
| 2 | [INTERACTION_AND_MOTION_EN.md](INTERACTION_AND_MOTION_EN.md) | Composition, intent modes, signature interactions, choreography, responsive behavior and storyboard |
| 3 | [DATA_AND_CONTRACTS_EN.md](DATA_AND_CONTRACTS_EN.md) | Semantic-analysis remediation, routing correctness, projection isolation and extensible Dealer contracts |
| 4 | [ACCEPTANCE_MATRIX_EN.md](ACCEPTANCE_MATRIX_EN.md) | Testable acceptance criteria, evidence rules and milestone release gates |
| 5 | [START_PROMPT_EN.md](START_PROMPT_EN.md) | Copyable next-agent assignment and explicit scope modes |

V3 is the successor plan for the next phase. It supersedes conflicting implementation choices in the isolated `intelligent-atlas/` prototype, including generic single-card restrictions, payload hiding as public isolation, and matcher completion as semantic completion. Preserve that prototype and its evidence as a dated baseline.

The [English V2 guide](../homepage-agent-handoff-v2-en-20261031/AGENT_GUIDE_EN.md), [graph specification](../homepage-agent-handoff-v2-en-20261031/INTELLIGENT_ATLAS_SPEC_EN.md) and [future contracts](../homepage-agent-handoff-v2-en-20261031/FUTURE_CONTRACTS_EN.md) remain supporting detail where compatible. Repository AGENTS and active scientific/publication policies still apply. The latest owner instruction determines what an executing agent may change.

Default next assignment: repair and extend the isolated review experience through M0–M5. Canonical Home integration M6–M7 is fully specified for a full-local assignment; forwarding the default prompt does not silently authorize it. No scope mode authorizes deployment or scientific publication.

Validation of this document package is in [PACKAGE_VALIDATION.json](PACKAGE_VALIDATION.json). [HANDOFF_STATUS.json](HANDOFF_STATUS.json) separates planning checks from future application checks. Run `rtk proxy node docs/knowledge-stage-next-phase-v3-20261101/verify-package.mjs` from the repository to recheck local document links and preservation against this preparation snapshot. Source changes after this delivery should be investigated as later work, not overwritten to satisfy the snapshot.

