# DP-600 R10 → R11 Scientific QA — AGENT START HERE

**Mission:** Resolve the 70 scientific blockers in the preserved 222-question DP-600 V3 bank. R10 first-pass assessment is complete; do NOT repeat OCR or restart the earlier B00–B09 audit.

## Execute in this order

1. Read `HANDOFF/AGENTS.md`, `HANDOFF/WORK_KICKOFF_PROMPT_EN.md`, `HANDOFF/STATE_AND_AUTHORITY.md`, `HANDOFF/EXECUTION_PLAYBOOK.md`, and `HANDOFF/RELEASE_GATES.md`.
2. Run `python TOOLS/verify_handover.py` at this package root. The nested R10 baseline will be checked against SHA-256 and all 222 source records, 70 queued blockers, original-answer/learner-answer differences, and R10 scientific statuses. No edits until PASS.
3. Run `python TOOLS/initialize_workspace.py --output ./R11_WORKSPACE`. Then run, from the extracted reference archive, `python CHECKS/verify_final_firstpass.py` and `python CHECKS/reproduce_checks.py`. Work only on fresh copies under `R11_WORKSPACE/WORKING_R11`; never edit `BASELINE/` or original R10 artifacts.
4. Open `QUEUES/PRIORITIZED_R11_WORK_ORDERS_70.csv` and `QUEUES/R11_WAVE_MAP.json`. Resolve W01–W07 in order; batches are 10 blocker IDs each. An agent may reorder WITH a logged reason; no omissions.
5. Correct **scientific content**, not only status flags: fix stems/options/keys and explanations in a separate candidate overlay, check original screenshots and full case study context, revalidate each option, cite current official docs, preserve reversible changes. Challenge earlier R10 decisions if evidence contradicts them.
6. Record actual runtime runs when accessible (Fabric Warehouse / SQL, Spark, PySpark, Power Query, KQL, DAX / Power BI), with commands, environment and observed output. Otherwise log `NOT_RUN`/`BLOCKED_RUNTIME` and unresolved impact; do not invent execution.
7. After each 10-question wave deliver a validated, self-contained R11 checkpoint and a live updated queue. Proceed autonomously through remaining waves. Publish release-approved output ONLY if every gate is satisfied; otherwise a truthful partial checkpoint with named unresolved IDs.

## R10 verified authority
- Source: `DP600_Scientific_QA_R10_2026-10-26_SELF_CONTAINED.zip` (included under `BASELINE/`, SHA-256 `404426335528640369e6a74c802c90505a920d0154433472a729515b10368506`)
- 222/222 reviewed, **105 approved**, **47 approved with nonblocking edits**, **41 correction proposals**, **29 ambiguous**; 70 blocked / 152 approval candidates.
- 70 blockers = **36 P0 + 34 P1**. No current product runtime tests (`NOT_RUN`); no deployment.
- Four original official-answer vs learner-answer mismatches: **T1Q120, T1Q193, T1Q221, T1Q222**; compare `officialAnswer` and `answer` fields directly in V3. R10 QA snapshot naming is misleading for these four.
- R10 release gate: **NO_GO_FULL_222**. The 152 subset is a research candidate, not deployed.

## Paths
- All R10 originals, evidence images, source docs and scripts are inside the nested ZIP under `BASELINE/`.
- `HANDOFF/`: scope, operation, scientific and UX criteria, release gates.
- `QUEUES/`: first-wave order and preserved R10 queues.
- `TEMPLATES/`: second-pass decisions, reversible answer changes and runtime evidence.
- `TOOLS/`: package verifier and safe initialization.

## Critical boundaries
No editing other Hansa DP-600/PL-300 banks; no Git commits to `D:\BeUI\amir-portfolio` without verified access and a separately authorized implementation scope; no Hansa deployment; no false Microsoft endorsement; no source-key overwrites.
