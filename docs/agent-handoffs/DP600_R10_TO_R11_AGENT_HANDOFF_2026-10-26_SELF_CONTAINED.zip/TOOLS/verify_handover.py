#!/usr/bin/env python3
"""Read-only, standard-library verification for the DP600 R10→R11 handoff.
Run from any directory: python /path/to/package/TOOLS/verify_handover.py
"""
import csv, hashlib, io, json, zipfile, pathlib, collections, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]

def fail(msg): raise AssertionError(msg)
def sha(buf):return hashlib.sha256(buf).hexdigest()
def csv_rows(z,n):return list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))))
def main():
 manifest=json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8'))
 for name,expected in manifest['sha256'].items():
  p=ROOT/name
  assert p.is_file(),f'missing: {name}'
  assert sha(p.read_bytes())==expected,f'file hash mismatch {name}'
 b=ROOT/'BASELINE'/manifest['r10_zip']
 assert sha(b.read_bytes())==manifest['r10_sha256'],'R10 archive does not match trusted snapshot'
 with zipfile.ZipFile(b) as z:
  assert z.testzip() is None,'damaged nested R10'
  for name in z.namelist():
   assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts,'unsafe ZIP path'
  questions=json.loads(z.read('BASELINE/dp600-image-free-structured-v3.json'))['questions']
  qs={v['id']:v for v in questions};assert len(qs)==222 and len(questions)==222,'source question IDs/count incorrect'
  qa=csv_rows(z,'OUTPUT/scientific_qa_master.csv');
  assert len(qa)==222 and set(x['id'] for x in qa)==set(qs),'R10 QA mismatch'
  c=collections.Counter(x['scientific_status'] for x in qa)
  assert c=={'APPROVED':105,'APPROVED_WITH_NONBLOCKING_EDITS':47,'CORRECTION_PROPOSED':41,'AMBIGUOUS':29},f'R10 status mismatch {c}'
  queue=csv_rows(z,'OUTPUT/SCIENTIFIC_CORRECTION_AND_AMBIGUITY_QUEUE_70.csv')
  assert len(queue)==70 and len({x['id'] for x in queue})==70,'R10 queue cardinality issue'
  blocked={x['id'] for x in qa if x['scientific_status'] in ('CORRECTION_PROPOSED','AMBIGUOUS')}
  assert {x['id'] for x in queue}==blocked,'R10 queued IDs do not match blockers'
  assert collections.Counter(x['severity'] for x in queue)=={'P0':36,'P1':34},'R10 severity counts incorrect'
  mismatches={k for k,v in qs.items() if 'answer' in v and v['officialAnswer']!=v['answer']}
  assert mismatches=={'T1Q120','T1Q193','T1Q221','T1Q222'},f'original and learner-key mismatch set changed: {mismatches}'
  decision=json.loads(z.read('OUTPUT/RELEASE_GATE_DECISION.json'))
  assert decision.get('decision')=='NO_GO_FULL_222' and not decision.get('passed'), 'R10 release state is not the expected NO-GO'
 orders=list(csv.DictReader((ROOT/'QUEUES/PRIORITIZED_R11_WORK_ORDERS_70.csv').open(encoding='utf-8-sig',newline='')))
 assert len(orders)==70 and {x['id'] for x in orders}==blocked,'R11 work-order scope mismatch'
 for row in orders:
  rec=qs[row['id']]
  assert json.loads(row['original_officialAnswer_FROM_V3'])==rec['officialAnswer'],f'officialAnswer snapshot mismatch for {row["id"]}'
  assert json.loads(row['original_learner_answer_FROM_V3'])==rec.get('answer'),f'learner answer snapshot mismatch for {row["id"]}'
 waves=json.loads((ROOT/'QUEUES/R11_WAVE_MAP.json').read_text(encoding='utf-8'))
 assert len(waves)==7 and all(x['count']==10 for x in waves),'Expected seven waves of 10'
 assert [i for w in waves for i in w['ids']]==[x['id'] for x in orders],'wave order differs from CSV'
 assert sum(x['P0'] for x in waves)==36 and sum(x['P1'] for x in waves)==34,'wave severity totals differ'
 results={'PASS':True,'authoritative_baseline_sha256':manifest['r10_sha256'], 'R10_original_source_count':222,
  'R10_scientifically_assessed':222,'previous_approved_candidates':152, 'remaining_blockers':70,'P0':36,'P1':34,
  'source_vs_learner_key_conflicts':sorted(mismatches),'seven_waves':True,'files_hashed_and_verified':len(manifest['sha256']),
  'product_runtime':'NOT_RUN','Hansa_deployment':False}
 print(json.dumps(results,indent=2)); return 0
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:print(f'FAIL: {e}',file=sys.stderr);sys.exit(1)
