#!/usr/bin/env python3
"""Make immutable reference + editable derived workspace from nested R10 ZIP; never overwrites existing workspace."""
import argparse, pathlib, shutil, zipfile, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',default='R11_WORKSPACE');args=p.parse_args()
 target=pathlib.Path(args.output).resolve()
 if target.exists():
  print(f'ABORT: workspace exists, refusing overwrite: {target}',file=sys.stderr);return 2
 b=next((ROOT/'BASELINE').glob('DP600_Scientific_QA_R10_*_SELF_CONTAINED.zip'))
 reference=target/'R10_READ_ONLY';reference.mkdir(parents=True)
 with zipfile.ZipFile(b) as z:
  for name in z.namelist():
   parts=pathlib.PurePosixPath(name).parts
   if name.startswith('/') or '..' in parts:raise ValueError(f'Unsafe ZIP member: {name}')
  z.extractall(reference)
 working=target/'WORKING_R11'; working.mkdir()
 for rel in ['OUTPUT','TRACKING','REFERENCES']:
  shutil.copytree(reference/rel,working/rel)
 shutil.copytree(ROOT/'QUEUES',working/'R11_QUEUES')
 shutil.copytree(ROOT/'TEMPLATES',working/'R11_TEMPLATES')
 (working/'R11_STAGE.txt').write_text('R11 scientific correction work area; original R10 remains immutable in sibling R10_READ_ONLY and handoff BASELINE.\n')
 print('Created:',target)
 print('R10 reference:',reference)
 print('Editable derived working files:',working)
 print('NEXT: cd',reference,'and run python CHECKS/verify_final_firstpass.py then python CHECKS/reproduce_checks.py')
 return 0
if __name__=='__main__':sys.exit(main())
