# R11 release gates — fail closed

**G0 Baseline:** Original R10 ZIP sha verified; 222 unique original IDs and unmodified `officialAnswer`, `answer`, case studies, stems, source choices, visual and source references. If G0 fails, STOP and restore baseline.

**G1 Full disposition:** 70 blockers have explicit R11 decisions and timestamps; all 222 appear in the regenerated master; no missing option/subpart analysis. `CORRECTION_PROPOSED`, `AMBIGUOUS`, `BLOCKED_RUNTIME`, `REJECTED`, and unverified edits are NOT grade-eligible.

**G2 Technical validity:** Every approved candidate has exact Microsoft documentation evidence, a unique answer under stated constraints, correct product mode/SKU/version, non-misleading and complete explanation, plausible distractors, and separately recorded source/learner/candidate keys. If SQL/DAX/KQL/PySpark/M ambiguities require execution, do not silently substitute reasoning for actual runtime.

**G3 Source/visual:** Every material screenshot-dependent decision has independent source-screenshot check; reconstructed charts/tables/relationships/code retain all task-relevant semantics. Block if source PDF absence prevents resolution and nested screenshot evidence is insufficient.

**G4 Calibration:** Follow DP-600 exam outline effective 2026-10-19. Map every item to the true domain, flag duplicates (6 stem clusters/18 records in R10), answer leakage, and repetitive superficial prompts. Do not present the question bank as official Microsoft exam content.

**G5 Interaction & product runtime:** Record exact test environment, steps, and outcomes. Real product runtime needs an actual Microsoft Fabric/Power BI/etc session. Mark `NOT_RUN`/`BLOCKED_RUNTIME` if missing. Browser/UI E2E is separate from scientific correctness and must be rerun on changed learner format before deployment approval.

**G6 Packaging:** New checkpoint contains immutable baseline, full R11 patched candidate bank, 222-row QA master, per-option review and evidence, 70-row disposition, before/after ledger, original-vs-learner-vs-candidate key report, tested/untested matrix, hashes, independent verifier, and truthful release declaration.

**G7 Integration:** Hansa repository not in scope; never deploy or modify any other Hansa bank. Full scientific GO does not automatically grant Hansa deployment approval.

**GO only if G0–G6 truly pass and all 222 are grade-eligible.** Otherwise NO_GO_FULL_222 with exact blocked IDs and reasons; a smaller gated subset can be emitted separately and labeled candidate. This is a release-policy choice, not a retrospective claim that 70 blockers were resolved.
