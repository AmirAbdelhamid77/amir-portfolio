# Definition of Done — each repaired question

A question reaches R11 `APPROVED_CORRECTED` only if ALL conditions hold:
1. Complete prompt, all choice text, relevant scenario, code/table and case constraints reconstructed without loss of key facts; original source snapshot pinned.
2. Correct response independently reasoned and supported by at least one exact current official Microsoft page, including access date, product mode/version and assumptions.
3. Each candidate answer option checked for true/false and rationale; multi-select count, dropdown slots, matrices, drag/drop and hotspot mappings independently resolved.
4. All prior source error(s) removed (not papered over by an explanation); answer can be obtained from the stem and exhibits, without hidden information; unique defensible grading outcome.
5. Revised distractors credible and non-leading; explanation explains why the chosen answer works and why each alternative does not.
6. Original official and learner keys unchanged, including optional/multipart grading keys; corrected candidate new field/patch plus reversible before/after diff.
7. Relevant screenshot/data/model diagram semantics checked against nested evidence; unsupported visual evidence leads to BLOCKED_SOURCE.
8. Runtime result logged only if real engine executed; if needed and absent, remains BLOCKED_RUNTIME.
9. Second-pass adversarial review records who/what actually reviewed and whether it was independent human or model; do not mislabel.
10. Corrected item retested with structural/lint and applicable logic/interaction checks; package manifest and 222/70 counts pass.

Any missing essential condition leaves the item scientifically blocked and not grade-eligible.
