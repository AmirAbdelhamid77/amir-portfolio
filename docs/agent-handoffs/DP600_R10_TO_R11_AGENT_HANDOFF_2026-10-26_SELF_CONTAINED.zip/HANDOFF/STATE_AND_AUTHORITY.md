# Authority and verified state

## Baseline hierarchy
1. Immutable V3 record in `BASELINE/dp600-image-free-structured-v3.json` *inside nested R10 ZIP*, including `officialAnswer` (the source key) and `answer` (learner current answer). Preserve both fields and all original IDs/content/provenance.
2. R10 completed first-pass review in `OUTPUT/scientific_qa_master.csv`, `OUTPUT/scientific_findings.json`, and `OUTPUT/before_after_changes.csv` inside R10 ZIP.
3. R10 70 blocker queue and release gate, current only as of **2026-10-26**. All prior review judgments are open to correction if evidence contradicts them.
4. Current official Microsoft Learn product documentation & DP-600 skills measured effective **2026-10-19** for scientific rulings.

## Verified package state
- 222 unique V3 records, 222 reviewed in R10; original source IDs and answer fields intact.
- Review status: APPROVED 105; APPROVED_WITH_NONBLOCKING_EDITS 47; CORRECTION_PROPOSED 41; AMBIGUOUS 29.
- P0 36; P1 34 in blocker queue. 70/70 runtime status NOT_RUN; no Fabric service accessed.
- 4 genuine dual-key mismatches (`officialAnswer != answer`): T1Q120, T1Q193, T1Q221, T1Q222.
- Release gate NO-GO for complete 222. 152 approved candidates do not establish website deployment approval.

## Discovered snapshot naming ambiguity
In R10 `scientific_findings.json` and some QA fields, `source_key_snapshot_UNCHANGED` may represent the learner `answer` instead of source `officialAnswer` for four mismatch cases. Treat field labels as untrusted. Do **not** treat R10 `source_key_snapshot` as the canonical original key without comparing both immutable V3 properties. For example T1Q221 original `officialAnswer=C`, learner `answer=B`, finding snapshot `B`.

## Known handoff issue carried forward
`OUTPUT/NEXT_SESSION_START_HERE.md` inside R10 contains an uninterpolated template for the blocker count; this R11 handoff supersedes that convenience note but does not modify the R10 archive.

## No-access attestations
No runtime checks in Microsoft Fabric, Power BI service, warehouse, Spark notebook, XMLA or KQL have been executed; local scripts check structure and deterministic heuristics only. The Hansa Windows repository `D:\BeUI\amir-portfolio` was not accessed by this packaging step. No deployment is in scope.
