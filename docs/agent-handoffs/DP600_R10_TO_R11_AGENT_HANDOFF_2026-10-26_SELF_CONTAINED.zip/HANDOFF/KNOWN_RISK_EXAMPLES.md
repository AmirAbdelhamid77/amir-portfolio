# Known high-priority scientific risks (leads, not assumed outcomes)

- T1Q174: `TRY_CAST(... AS varchar(20))` does not perform overlength-to-NULL validation; check actual SQL statement schema/filter and alternative expression.
- T1Q5: Lakehouse 'Read all with Apache Spark' is a read permission, not write permission.
- T1Q7: stray closing bracket and outdated default semantic model assumption.
- T1Q34: Power Query folding icons in original screenshot absent in image-free reconstruction; restore accessible semantics.
- T1Q48: Delta `OPTIMIZE`/`VACUUM`, log retention and exact file target conflated.
- T1Q65: source data Delta but code reads CSV.
- T1Q81/T1Q127: retired automatic default semantic-model provisioning/synchronization.
- T1Q97: `COALESCE` precedence reversed; nonnullable ListPrice masks preferred columns.
- T1Q108: DAX quoted table identifier contains trailing space.
- T1Q112: deprecated Spark Runtime 1.2 starter pool assumptions.
- T1Q120/T1Q193/T1Q221/T1Q222: original official key != learner key; separately validate both.
- T1Q133: DirectLakeOnly cannot have DirectQuery fallback.
- T1Q158: integer division loses fractional mean unless cast/decimal chosen.
- T1Q194: undocumented deployment rules for Dataflow Gen2.
- T1Q198: KQL `row_window_session` with 0m gap does not implement the required per-hour grouping.

Use these as investigation triggers; before marking each APPROVED, re-check the exact current documentation and original question wording.
