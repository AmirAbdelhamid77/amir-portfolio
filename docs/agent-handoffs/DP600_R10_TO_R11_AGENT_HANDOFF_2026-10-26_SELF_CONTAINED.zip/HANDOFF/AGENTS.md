# AGENTS.md — Agent operating contract for this handoff

This AGENTS.md applies only to this handoff package. If you later operate inside the Hansa repository, read the repository root AGENTS.md and nested instructions first; this document does NOT override them.

- **Preserve:** R10 ZIP, source V3 JSON, officialAnswer, answer, original source IDs, case studies, original citations, provenance, previous releases, original screenshots and QA history.
- **Write ONLY derived outputs** under new R11 working directories; every change must be reversible; append signed/dated second-pass decisions.
- **Follow official Microsoft Learn** effective exam outline 2026-10-19; check live docs and context/version at execution time. Previous R10 links are hypotheses/leads, not a substitute for R11 validation.
- **Independent review:** require someone/another logically independent pass to verify each patched answer and all distractors; differentiate 'recommendation' from 'applied & tested'.
- **Fail closed:** if not all selection options uniquely defensible, do not approve. If real product runtime unavailable and required, use BLOCKED_RUNTIME, not PASS.
- **Stop deployment:** no edits to Hansa or other question banks, no website deployment, no source-control changes to external projects.
- **Persistent checkpoints:** after every 10 IDs, validate counts, source hashes, dated citations, update QA/changes/queue, and write a full resumable ZIP. Save/return current deliverables.
- **No manufactured QA:** synthetic static tests are not Fabric/Power BI/KQL/DAX/Spark runtime tests. Correct scientific errors before counting release approvals.
