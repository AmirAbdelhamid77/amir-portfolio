# R11 end-to-end execution playbook

## Phase 0 — Provenance and smoke tests
Verify new ZIP and R10 checks. Extract R10 to read-only reference directory. Compare every original id, stem, all choices, question type, officialAnswer, learner answer and caseStudies; pin hashes from source V3 and QA register. Show reproducible pass/fail before modifications. Confirm version-specific docs and the actual current skills outline.

## Phase 1 — Repair wave W01 through W07
See `QUEUES/PRIORITIZED_R11_WORK_ORDERS_70.csv`. For each item:
1. Re-read the full source V3 question, choices, all semanticVisuals, source citations and case study; check original recovered screenshot when diagram/code/folding icon is material.
2. Solve independently. Evaluate EACH incorrect choice and selection count; check ambiguous, stale, mutually contradictory, preview/GA or role/permission assumptions.
3. Open current **official** Microsoft docs, inspect exact relevant sections; preserve URL, date, version, SKU, context, reasoning, and counters. R10 references do not automatically satisfy second-pass evidence.
4. Author candidate patched question/choices/correct key/explanation in a separate derived JSON. Preserve officialAnswer/source and learner original, plus rich provenance. For dropdown/matrix/dragdrop update every region and ensure accessible semantics.
5. Check syntax and arithmetic with safe deterministic counterexamples. If relevant product runtime is available, execute a real test (record environment, exact commands and raw output). If it isn't, log NOT_RUN/BLOCKED_RUNTIME and distinguish inconclusive from source-grounded issues.
6. Request independent second review or perform an adversarial second evaluation with a separately reasoned evidence pass; never call it a distinct human review if it is not. Require defensible unique key and plausible distractors.
7. Update per-id R11 decision/justification, before/after append-only ledger, official citations, case/visual fidelity proof, learner grading gate and unresolved severity. Do not mutate historical R10 rows in place.
8. Run integrity gates; produce self-contained incremented checkpoint after each wave. If a blocker remains unresolved, keep it blocked.

## Phase 2 — Bank-level scientific and exam calibration
Review 47 approved-with-edit records for proposed pedagogical improvements; do not quietly change their baseline status. Reassess all 222 items' distractor/explanation consistency and source-key conflicts; check precise current domain distribution, 6 identical-stem clusters (18 records), option-length leakage heuristic, realistic decision framing and question-format behaviors. Record 2026-10-19 exam domain mapping and candidate corrective selection strategy. Do not delete duplicate historical source IDs.

## Phase 3 — Release candidates
Produce (A) FULL_222_CORRECTED_CANDIDATE_NOT_DEPLOYED with provenance/patch set; (B) APPROVED_SCIENCE_GATED_LEARNER_BANK consisting only of scientifically defensible items, unless all 222 pass; (C) 222-row QA master, logs, test results, docs references; (D) immutable originals; (E) separate NO_GO or GO decision supported by per-gate evidence; (F) R12 continuation queue for unresolved IDs, if any.

## Phase 4 — Final checks
- Hash and compare original V3 source and R10 ZIP.
- Programmatically check IDs and no mutation of every original officialAnswer and original learner answer; record candidate key in *separate* field.
- Verify no contradictions between original answer, source key, learner key and approved candidate key.
- Verify every reviewed question and every target part has tested/discussed options and written rationales.
- Verify actual supported docs checked with timestamps, real product runs only where observed, no undocumented PASS.
- UI interaction/browser E2E acceptance only if actually executable in the environment; avoid claiming R10 UI results represent new R11 UI tests.
- No Hansa modification, Git commit, or deployment; if integration requested later read repository AGENTS.md and check `git status` first.

## Wave completion reports
For each 10-ID wave include: IDs tackled, keys corrected vs original, ambiguities resolved/unresolved, documentation findings, test status (real/static/not run), schema/visual repairs, QA ledger hashes, approvals net added, release gate, next wave and locations of files.

## Budget and stop conditions
Work autonomously across waves; do not ask for confirmation for documented scope. Never claim work took place asynchronously. If blocked by a real tenant, access, source evidence or runtime prerequisite, publish an honest checkpoint and list exact dependent items/commands necessary to resume.
