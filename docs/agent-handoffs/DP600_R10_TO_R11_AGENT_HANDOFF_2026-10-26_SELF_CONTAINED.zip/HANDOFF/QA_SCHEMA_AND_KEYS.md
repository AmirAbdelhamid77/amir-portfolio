# Canonical fields and key preservation

- V3 `questions[].id`: immutable original source ID.
- V3 `questions[].officialAnswer`: immutable original SOURCE (PDF/source-extract) answer key. It may be scientifically wrong.
- V3 `questions[].answer`: optional immutable current LEARNER answer at V3. It exists on simple items but is **absent from many multipart or visual-format items**. When absent, inspect the semanticVisuals/subpart grading fields; absence is not a mismatch. Where present, it can differ from `officialAnswer`.
- R10 `scientific_findings[].source_key_snapshot_UNCHANGED`: **not guaranteed to be PDF source answer**; confirmed that for T1Q120, T1Q193, T1Q221, T1Q222 this is learner key. Always independently compare raw V3 `officialAnswer` and `answer`.
- R10 `proposed_answer_separate` / `reviewed_answer_proposal`: a scientific recommendation, NOT applied.
- R11 new candidate `correctedAnswer` / `scientific_approved_answer`: new property in separate derived JSON, never an in-place overwrite of above source fields.
- For multipart item types, a string key may be insufficient. Preserve and compare object/array subparts and selection order where meaningful.
- Key validity must be tested not inferred from a matching letter; verify answer text/index/key-to-option mapping after any reordering.
- Before/after record stores all three layers; date, exact evidence, new assumption, review status, test result, and reversible patch application method.

## Four explicit key conflicts

| ID | Original officialAnswer | Original learner answer | R10 status |
|---|---|---|---|
| T1Q120 | D | C | CORRECTION_PROPOSED |
| T1Q193 | A | D | CORRECTION_PROPOSED |
| T1Q221 | C | B | CORRECTION_PROPOSED |
| T1Q222 | C | B | CORRECTION_PROPOSED |

These are comparison values from immutable V3 source. Source-vs-learner disagreement itself is not final evidence of which answer is scientifically correct.
