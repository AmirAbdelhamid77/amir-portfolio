# Official Microsoft entry points — verify current pages while auditing

- **Current exam outline (skills measured as of 2026-10-19):** https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/dp-600
- **Fabric Analytics Engineer certification:** https://learn.microsoft.com/en-us/credentials/certifications/fabric-analytics-engineer-associate/
- **Microsoft Fabric docs:** https://learn.microsoft.com/en-us/fabric/
- **Power BI guidance / star schema:** https://learn.microsoft.com/en-us/power-bi/guidance/star-schema
- **Direct Lake:** https://learn.microsoft.com/en-us/fabric/fundamentals/direct-lake-overview
- **Fabric permissions:** https://learn.microsoft.com/en-us/fabric/security/permission-model
- **Power Query merge:** https://learn.microsoft.com/en-us/power-query/merge-queries-overview
- **T-SQL TRY_CAST:** https://learn.microsoft.com/en-us/sql/t-sql/functions/try-cast-transact-sql
- **T-SQL CAST/CONVERT:** https://learn.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql
- **KQL prev():** https://learn.microsoft.com/en-us/kusto/query/prev-function
- **Git integration:** https://learn.microsoft.com/en-us/fabric/cicd/git-integration/intro-to-git-integration

Only use these as entry points; open the exact documentation relevant to each decision. Official sources can change, so log access date and product context. Source-bank Microsoft links may be stale.
