# DP-600 source HTML embedded image forensic audit

Input: index.html (single-file DP-600 practice app). The original upload is unchanged.

## Verified findings

- Embedded image-map entries: **238**. Each is a complete Base64 PNG in `window.__IMGMAP`.
- All images decoded and passed PIL image integrity verification: **238/238**.
- Question records in embedded HTML: **222**.
- Question records identical to uploaded `dp600-questions-2026-10-25.json`: **MATCH** (field-for-field, same order).
- Questions with at least one `exhibits` entry: **98**.
- Questions with at least one `answerImages` entry: **80**.
- Questions referencing any image: **98**.
- Total exhibit references: **147**.
- Total answer-key references: **81**.
- Unique images referenced by questions: **228**.
- Case-study source-image references: **2**.
- Unique references across questions/cases: **230**; missing from image map: **0**.
- Embedded, currently unreferenced images: **8** (kept for provenance; not necessarily required).
- Distinct PNG content hashes: **234**; some embedded images are exact duplicates.
- No remote image request is required for the **referenced** assets: each reference resolves through the in-file map. The JS contains a fallback `data/img/` path for unknown identifiers.

## Important distinctions

1. **Source image exists:** The original HTML contains the actual image binary. An independent JSON file contains references but not binary images.
2. **Interactive controls exist:** Most hotspot/dropdown/drag-drop questions already encode selected options, targets, and answers as structured data. Their screenshots may be redundant once the interactive controls are confirmed complete.
3. **Question input completeness:** Certain exhibits have facts not in `stem`, and can make a question impossible to solve without retrieving the exhibit content. Examples: T1Q91 (Performance Analyzer timings), T1Q98 (Python code and histogram), T1Q156 and T1Q192 (workspace comparison tables), T1Q195 (model table/column relationships).
4. **Case-study completeness:** `cs_litware` references `p019_i1.png` and `p019_i2.png`, containing source data and Product column information missing from plain case-study text.
5. **Answer leakage:** `answerImages` is answer-key evidence. It must remain hidden until grading or review, and must never be used as a question-stem illustration by mistake.

## Recommended Hansa integration

- Preserve canonical question IDs and raw source metadata, plus SHA-256 for every referenced image.
- Create two fields: `sourceVisualReferences` (historical filenames) and `requiredPromptContent` (semantic HTML tables, code blocks, diagrams or data visualizations).
- Independently check image relevance/completeness for each question, not just the presence of `exhibits`. Do not mark all 98 as image-blocked.
- Prioritize 17 exhibit-referencing questions of `mcq`, `mcq-image`, `multi`, `yesno` types for manual content recovery; also review 2 case-study images and 81 other interactive question exhibits.
- Once verified, render semantic HTML/JSX instead of a screenshot where possible. Retain original image as archival QA evidence; question scoring is enabled only when required prompt facts are present and independently checked.
- Never use `answerImages` as a replacement for a question exhibit; avoid revealing answer highlights.
- Keep original `index.html`/JSON untouched. The attached files are read-only-derived assets and an audit.

## Pack contents

- `images/*.png`: all 238 original embedded PNG images.
- `embedded_images_manifest.json`: dimensions, SHA-256, usage roles, question IDs, integrity.
- `images_audit.csv`: one row per embedded image.
- `questions_with_images.csv`: one row per question referencing images.
- `SOURCE_IMAGE_AUDIT.md`: this report.
- `recover_dp600_images.py`: reproducible offline extraction script (requires Pillow).
