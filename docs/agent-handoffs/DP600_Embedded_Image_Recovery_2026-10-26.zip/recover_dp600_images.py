#!/usr/bin/env python3
"""Extract embedded PNGs from a user-supplied DP-600 single-file HTML, audit references, and package recoverable assets."""
from pathlib import Path
import json, base64, hashlib, csv, zipfile, io, collections
from PIL import Image
SOURCE=Path('/mnt/data/index.html')
BANK=Path('/mnt/data/dp600-questions-2026-10-25.json')
OUT=Path('/mnt/data/DP600_Embedded_Image_Recovery_2026-10-26.zip')
s=SOURCE.read_text('utf-8')
parser=json.JSONDecoder()
def var_obj(var):
    key='window.'+var+' = '
    if key not in s: raise ValueError('JS global not found: '+key)
    value,_=parser.raw_decode(s[s.index(key)+len(key):]);return value
images=var_obj('__IMGMAP');data=var_obj('DP600_DATA')
original=json.loads(BANK.read_text('utf-8')) if BANK.exists() else None
refs={}
for q in data['questions']:
    for kind in ('exhibits','answerImages'):
        for f in q.get(kind,[]): refs.setdefault(f,[]).append({'entity':'question','id':q['id'],'role':kind,'type':q['type']})
for c in data.get('caseStudies',[]):
    for image in c.get('images',[]): refs.setdefault(image['file'],[]).append({'entity':'caseStudy','id':c['id'],'role':'caseStudy.images','type':'caseStudy'})

rows=[];rawmap={};bad=[]
for filename,uri in images.items():
    assert filename.endswith('.png') and '/' not in filename and '..' not in filename
    if not uri.startswith('data:image/png;base64,'): raise ValueError('Unexpected encoding: '+filename)
    raw=base64.b64decode(uri.split(',',1)[1],validate=True)
    try:
        with Image.open(io.BytesIO(raw)) as im:
            dim=im.size; im.verify()
    except Exception as exc:
        bad.append((filename,str(exc)));continue
    rawmap[filename]=raw
    entries=refs.get(filename,[])
    rows.append({'filename':filename,'width':dim[0],'height':dim[1],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'references':len(entries),'used_by':';'.join(x['id'] for x in entries),'roles':';'.join(x['role'] for x in entries),'classification':'unreferenced' if not entries else ('case-study source data' if any(x['entity']=='caseStudy' for x in entries) else ('question exhibit' if any(x['role']=='exhibits' for x in entries) else 'answer-key image'))})
missing=sorted(set(refs)-set(images))
qs=[]
for q in data['questions']:
    exhibit=q.get('exhibits',[]); answers=q.get('answerImages',[])
    if not exhibit and not answers:continue
    qs.append({'question_id':q['id'],'type':q['type'],'case_study':q.get('caseStudy') or '', 'exhibit_count':len(exhibit),'answer_image_count':len(answers),'exhibits':';'.join(exhibit),'answer_images':';'.join(answers),'description':q.get('stem','').replace('\n',' ')[:280],'priority':'manual content review: source-data exhibit' if exhibit and q['type'] in ('mcq','mcq-image','multi','yesno') else ('verify interactive conversion and source dependencies' if exhibit else 'review answer key only')})

assert len(images)==238, len(images)
assert not missing, missing
assert not bad,bad
status='MATCH' if original and original['questions']==data['questions'] else 'DIFFERENT OR NOT AVAILABLE'
sumQ=collections.Counter(q['type'] for q in data['questions'] if q.get('exhibits') or q.get('answerImages'))
summary=f'''# DP-600 source HTML embedded image forensic audit

Input: index.html (single-file DP-600 practice app). The original upload is unchanged.

## Verified findings

- Embedded image-map entries: **{len(images)}**. Each is a complete Base64 PNG in `window.__IMGMAP`.
- All images decoded and passed PIL image integrity verification: **{len(rawmap)}/{len(images)}**.
- Question records in embedded HTML: **{len(data['questions'])}**.
- Question records identical to uploaded `dp600-questions-2026-10-25.json`: **{status}** (field-for-field, same order).
- Questions with at least one `exhibits` entry: **{sum(bool(q.get('exhibits')) for q in data['questions'])}**.
- Questions with at least one `answerImages` entry: **{sum(bool(q.get('answerImages')) for q in data['questions'])}**.
- Questions referencing any image: **{len(qs)}**.
- Total exhibit references: **{sum(len(q['exhibits']) for q in data['questions'])}**.
- Total answer-key references: **{sum(len(q['answerImages']) for q in data['questions'])}**.
- Unique images referenced by questions: **{len(set(f for q in data['questions'] for f in q['exhibits']+q['answerImages']))}**.
- Case-study source-image references: **{sum(len(c.get('images',[])) for c in data.get('caseStudies',[]))}**.
- Unique references across questions/cases: **{len(refs)}**; missing from image map: **{len(missing)}**.
- Embedded, currently unreferenced images: **{len(images)-len(refs)}** (kept for provenance; not necessarily required).
- Distinct PNG content hashes: **{len(set(row['sha256'] for row in rows))}**; some embedded images are exact duplicates.
- No remote image request is required for the **referenced** assets: each reference resolves through the in-file map. The JS contains a fallback `data/img/` path for unknown identifiers.

## Important distinctions

1. **Source image exists:** The original HTML contains the actual image binary. An independent JSON file contains references but not binary images.
2. **Interactive controls exist:** Most hotspot/dropdown/drag-drop questions already encode selected options, targets, and answers as structured data. Their screenshots may be redundant once the interactive controls are confirmed complete.
3. **Question input completeness:** Certain exhibits have facts not in `stem`, and can make a question impossible to solve without retrieving the exhibit content. Examples: T1Q91 (Performance Analyzer timings), T1Q98 (Python code and histogram), T1Q156 and T1Q192 (workspace comparison tables), T1Q195 (model table/column relationships).
4. **Case-study completeness:** `cs_litware` references `p019_i1.png` and `p019_i2.png`, containing source data and Product column information missing from plain case-study text.
5. **Answer leakage:** `answerImages` is answer-key evidence. It must remain hidden until grading or review, and must never be used as a question-stem illustration by mistake.

## Recommended Hansa integration

- Preserve canonical question IDs and raw source metadata, plus SHA-256 for every referenced image.
- Create two fields: `sourceVisualReferences` (historical filenames) and `requiredPromptContent` (semantic HTML tables, code blocks, diagrams or data visualizations).
- Independently check image relevance/completeness for each question, not just the presence of `exhibits`. Do not mark all 98 as image-blocked.
- Prioritize 17 exhibit-referencing questions of `mcq`, `mcq-image`, `multi`, `yesno` types for manual content recovery; also review 2 case-study images and 81 other interactive question exhibits.
- Once verified, render semantic HTML/JSX instead of a screenshot where possible. Retain original image as archival QA evidence; question scoring is enabled only when required prompt facts are present and independently checked.
- Never use `answerImages` as a replacement for a question exhibit; avoid revealing answer highlights.
- Keep original `index.html`/JSON untouched. The attached files are read-only-derived assets and an audit.

## Pack contents

- `images/*.png`: all {len(images)} original embedded PNG images.
- `embedded_images_manifest.json`: dimensions, SHA-256, usage roles, question IDs, integrity.
- `images_audit.csv`: one row per embedded image.
- `questions_with_images.csv`: one row per question referencing images.
- `SOURCE_IMAGE_AUDIT.md`: this report.
- `recover_dp600_images.py`: reproducible offline extraction script (requires Pillow).
'''

manifest={'source_filename':'index.html','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'json_question_records_match':status,'counts':{'images':len(images),'questions':len(data['questions']),'questions_with_images':len(qs),'questions_with_exhibits':sum(bool(q.get('exhibits')) for q in data['questions']),'questions_with_answer_images':sum(bool(q.get('answerImages')) for q in data['questions']),'exhibit_references':sum(len(q['exhibits']) for q in data['questions']),'answer_image_references':sum(len(q['answerImages']) for q in data['questions']),'referenced_unique_images':len(refs),'missing_referenced_images':len(missing),'orphaned_images':len(images)-len(refs),'bad_encoded_images':len(bad)},'images':rows,'image_question_references':refs}
def csv_bytes(data):
    out=io.StringIO(); writer=csv.DictWriter(out,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data);return out.getvalue().encode('utf-8-sig')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
    for f,raw in rawmap.items(): z.writestr('images/'+f,raw)
    z.writestr('embedded_images_manifest.json',json.dumps(manifest,indent=2,ensure_ascii=False))
    z.writestr('images_audit.csv',csv_bytes(rows))
    z.writestr('questions_with_images.csv',csv_bytes(qs))
    z.writestr('SOURCE_IMAGE_AUDIT.md',summary)
    z.writestr('recover_dp600_images.py',Path(__file__).read_bytes())
Path('/mnt/data/DP600_Source_Image_Audit_2026-10-26.md').write_text(summary,encoding='utf-8')
Path('/mnt/data/DP600_Questions_With_Visuals_2026-10-26.csv').write_bytes(csv_bytes(qs))
print('PACKAGE',OUT,OUT.stat().st_size)
print('Question type distribution',sumQ)
print(summary[:2400])
