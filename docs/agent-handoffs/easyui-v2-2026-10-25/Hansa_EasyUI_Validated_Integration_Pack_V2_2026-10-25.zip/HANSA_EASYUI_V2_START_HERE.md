# START HERE — Hansa EasyUI verified integration pack v2

**This is an updated recommendation and agent handoff. It does not contain installed components or modify/deploy Hansa.**

## Correct placement
Unzip **directly into** `D:\BeUI\amir-portfolio\`. The archive has root-relative `docs/...` paths and uniquely named `...V2...` files. It does **not** contain `AGENTS.md` and does not overwrite existing registry files.

## Agent starting point
`docs/agent-handoffs/HANSA_EASYUI_V2_KICKOFF.md`

## Registry
`docs/design-system/HANSA_EASYUI_V2_COMPONENT_MATRIX.md` and `.json`

Treat v2 as the authoritative EasyUI-specific recommendation over `HANSA_COMPONENT_REGISTRY` from the earlier pack, but do not override higher-priority current `AGENTS.md`, project design guidance, or implementation facts.

High-confidence first pilots: **Code Snippet Deck**, **Smart Comparison**, **Scroll Progress Navigation**, then **Product Tour** and **Dependency Trace mini-diagram** if local content supports them. No unconditional bulk install.
