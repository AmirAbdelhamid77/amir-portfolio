# Hansa EasyUI v2 — adoption ledger

All candidates begin **not-installed** (this is a blueprint). Record each decision below.

| Date | Component | Route | Existing beUI alternative | Decision | Source version/hash | Added deps | A11y/mobile/reduced-motion | Static build | Bundle impact | Rollback |
|---|---|---|---|---|---|---|---|---|---|---|
| 2026-10-25 | — | — | — | Blueprint only: repository not accessed | — | — | Not tested | Not tested | Not measured | — |
