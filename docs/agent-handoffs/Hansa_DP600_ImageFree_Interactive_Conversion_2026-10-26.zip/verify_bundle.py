#!/usr/bin/env python3
"""Source preservation, semantic completeness and image-free output acceptance gates."""
from pathlib import Path
import json,collections,hashlib,re,sys
from bs4 import BeautifulSoup
W=Path(__file__).resolve().parent
SRC=Path('/mnt/data/dp600-questions-2026-10-25.json')
raw=json.loads(SRC.read_text('utf8'))
out=json.loads((W/'dp600-image-free-structured.json').read_text('utf8'))
preview=(W/'DP600_ImageFree_Interactive_Preview.html').read_text('utf8')
assert len(raw['questions'])==len(out['questions'])==222
assert [q['id'] for q in raw['questions']]==[q['id'] for q in out['questions']]
assert len(set(q['id'] for q in out['questions']))==222
assert len(raw['caseStudies'])==len(out['caseStudies'])
assert not re.search(r'<img\b',preview,re.I)
assert 'data:image/png;base64' not in preview and 'window.__IMGMAP' not in preview
assert not re.search(r'<canvas\b',preview,re.I)
for a,b in zip(raw['questions'],out['questions']):
 for key in ('id','type','stem','caseStudy','answer','officialAnswer','explanation','blanks','statements','drag','refs','comments','pdfPages'):
  assert a.get(key)==b.get(key),(a['id'],key)
 assert not b['exhibits'] and not b['answerImages'],b['id']
 assert not any('image' in opt for opt in b.get('options',[])),b['id']
 if b['visualResolution']=='verified_transcription':assert b.get('semanticVisuals') or b['id']=='T1Q147'
 if b['gradingEnabled']:assert b['visualResolution'] in ('no_exhibit_needed','verified_transcription','structured_answer_area_verified')
 else: assert b['visualResolution'] in ('ocr_review_required','candidate_interactive_only_review')
for c in out['caseStudies']:
 assert not c['images']
 if c['id']=='cs_litware':assert len(c['semanticVisuals'])==2
soup=BeautifulSoup(preview,'html.parser')
assert not soup.select('img,canvas,video,picture')
js=soup.select_one('#bank-data'); data=json.loads(js.string)
assert len(data['questions'])==222
assert data['questions']==out['questions']
assert all(o.get('code') and not o.get('image') for q in out['questions'] if q['type']=='mcq-image' for o in q['options'])
counts=dict(collections.Counter(q['visualResolution'] for q in out['questions']))
assert sum(counts.values())==222
assert sum(q['gradingEnabled'] for q in out['questions'])==152
ocr=json.loads((W/'ocr_exhibits.json').read_text('utf8'))
assert len(ocr['entries'])==157
print('PASS: 222/222 IDs, stems, original answers, explanations, case links, answer widgets preserved')
print('PASS: no raster media / no image UI / all image-only SQL options converted to source-readable SQL')
print('PASS: 2 case-study data tables reconstructed; 157 source visuals OCR scanned')
print('PASS: 152 source-key graded, 70 review-gated; per-question rationale registered')
print('QA STATES',counts)
print('SHA256 generated JSON',hashlib.sha256((W/'dp600-image-free-structured.json').read_bytes()).hexdigest())
