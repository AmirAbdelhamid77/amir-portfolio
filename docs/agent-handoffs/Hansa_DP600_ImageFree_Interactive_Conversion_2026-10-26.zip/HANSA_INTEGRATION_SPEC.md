# Hansa implementation instructions — image-free DP-600 bank

## Access and preservation requirements

Do not assume repo access. Before changes, verify `D:\BeUI\amir-portfolio` is mounted/available, run `git status`, read `AGENTS.md` and nested AGENTS instructions, and inspect DP-600 academy and Knowledge Atlas manifests. Preserve previous DP-600 and PL-300 records; do not replace the master 1,366-source-record search corpus with the 222-record subset. This deliverable is **additive**, and does not supersede the latest knowledge-atlas continuation manifests or review/publication status.

## Mapping to first-party Hansa UI

- `questions[].semanticVisuals[].kind=table` => existing Hansa accessible Table component, preserving headers, cells and field names exactly.
- `kind=code` => existing syntax-highlighted CodeBlock (language `sql`, `python`, `dax`, `kql`, or `text`), no image.
- `kind=text` => plain semantic text.
- `kind=chart-description` => explanatory native text with correct axis labels; if the original graph's exact quantitative bins matter for scoring, **do not fabricate a numerical chart**, and keep the question review-gated until data are independently recovered.
- Existing `blanks`, `statements`, `drag`, `options` map to Hansa-native Dropdown, Yes/No choice, keyboard-accessible matching and single/multiple choice. No image use for answer controls.
- `options[].code` replaces screenshot-only SQL options in T1Q10 and T1Q147.
- `caseStudies[].semanticVisuals` map to case-study tables; source narrative stays complete.
- `visualOCRDrafts` must never be treated as learner-approved content. Keep in private QA/admin views.
- `sourceVisualReferences` is **historical provenance only**, not a media requirement or image URL. Do not mark a question missing images just because this metadata includes a `.png` filename.
- `gradingEnabled=false` means block automatic scoring. Offer a non-graded preview only if source uncertainty is communicated.
- Keep a **separate scientific status**: `scientific_review_pending`, `scientifically_verified`, etc. Do not mistake pixel transcription for scientific approval.

## Acceptance gates

1. No original source/asset deleted, no ID/answer/question-text loss, no provider credentials or paid integrations.
2. User-facing DP-600 question UI **contains zero image elements** and **zero data-uri raster assets**; use native components and screen reader descriptions.
3. Verify options aren't accidentally the answer-key screenshots; explanations and answer highlights appear only after submit/reveal.
4. A held question cannot produce a score or falsely claim completion; the per-question status is visible to reviewers.
5. Support mobile, keyboard/touch, high contrast, dark/light and text selection without overflow.
6. Reproduce `verify_bundle.py` plus repo-specific QA and browser E2E before marking release deployable.
7. Do not deploy or publish unapproved Atlas knowledge content as an incidental side effect.

## Prioritized remainder

- 64 content-bearing screenshot questions: diagrams, screenshot data metrics, multi-table SQL questions, embedded DAX/Python/KQL code. Recover exact semantic facts from the original HTML visual map; OCR drafts are available for triage.
- Six answer-template screenshots: `T1Q72`, `T1Q74`, `T1Q82`, `T1Q90`, `T1Q102`, `T1Q159` require confirmation of surrounding code/statement context, beyond structured blanks.
- Independently audit question answers for product/documentation drift, not addressed by this visual-conversion task.
