#!/usr/bin/env python3
"""Generate image-free, review-gated DP-600 question bank from supplied source + OCR."""
from pathlib import Path
import json,hashlib,copy,csv,io,re,collections,zipfile,html
P=Path('/mnt/data'); W=P/'dp600_transform_work'; W.mkdir(exist_ok=True)
SRC=P/'dp600-questions-2026-10-25.json'; ORIGINAL=P/'index.html'
raw=json.loads(SRC.read_text('utf-8'));ocr=json.loads((W/'ocr_exhibits.json').read_text('utf-8'))['entries']

def table(headers,rows,title='Source exhibit'):
 return {'kind':'table','title':title,'headers':headers,'rows':rows}
def code(content,language='text',title='Source exhibit'):
 return {'kind':'code','title':title,'language':language,'content':content.strip()}
def prose(content,title='Source exhibit'):
 return {'kind':'text','title':title,'content':content.strip()}
def bars(title,labels,description):
 return {'kind':'chart-description','title':title,'labels':labels,'description':description}
manual={}
def add(ids,blocks,comment='Transcribed from source image; retains relevant prompt data'):
 for q in ids.split():manual[q]={'blocks':copy.deepcopy(blocks),'note':comment}
add('T1Q10',[table(['Name','Data type','Nullable'],[
 ['ProductID','Integer','No'],['ProductName','Varchar(30)','No'],['SalesDate','Datetime2(6)','No'],['WholesalePrice','Decimal(18,2)','Yes'],['Amount','Decimal(18,2)','Yes']], 'Staging.Sales schema')])
add('T1Q19',[table(['Column statistic','Value'],[['Column','pickupLongitude'],['Count (profiled)','1000'],['Error count','0'],['Null count','0'],['Distinct count','935'],['Unique count','871'],['NaN count','0']], 'Power Query column profile')], 'Transcribed column statistics; screenshot also contains a distribution preview.')
add('T1Q32',[table(['Name','Data type','Description'],[
 ['OrderID','Integer','Column imported from the source'],['OrderDateTime','Date/Time','Column imported from the source'],['Quantity','Integer','Column imported from the source'],['Price','Decimal','Column imported from the source'],['TotalSalesAmount','Decimal','Calculated column that multiplies Quantity and Price'],['TotalQuantity','Integer','Measure']], 'Orders fields')])
add('T1Q42',[table(['Source field','Purpose'],[['VendorID','Identifier column selected in Power Query'],['2015-01-01, 2015-01-02, …','Date-named columns containing numeric values']], 'Power Query wide-format input'),prose('The query has one row per VendorID, with separate date-named columns. VendorID is selected; the question asks how to turn all other columns into attribute/value rows.', 'Transformation context')], 'Source preview shows vendor/date-wide format; abbreviated sample rows because individual numeric rows are not required for choosing the unpivot command.')
add('T1Q91',[table(['Name','Duration (ms)'],[['DAX query','27'],['Visual display','39'],['Other','1047']], 'Performance Analyzer timing breakdown')])
add('T1Q96',[table(['Column','Quality','Value distribution','Counts shown'],[
 ['SalesOrderID','Valid 100%; Error 0%; Empty 0%','Bar distribution','32 distinct; 4 unique'],
 ['OrderDate','Valid 100%; Error 0%; Empty 0%','Bar distribution','19 distinct; 2 unique'],
 ['CustomerID','Valid 100%; Error 0%; Empty 0%','Bar distribution','32 distinct; 4 unique'],
 ['LineItem','Valid 100%; Error 0%; Empty 0%','Bar distribution','50 distinct; 4 unique'],
 ['ProductID','Valid 100%; Error 0%; Empty 0%','Bar distribution','142 distinct; 14 unique'],
 ['OrderQty','Valid 100%; Error 0%; Empty 0%','Bar distribution','19 distinct; 2 unique']], 'Power Query Data view shown')], 'Counts appear in condensed footer; first numerical figures visually read and normalized from the image.')
add('T1Q98',[
 code("""# Look at a histogram of tips by count by using Matplotlib
ax1 = sampled_taxi_pd_df['tipAmount'].plot(kind='hist', bins=25, facecolor='lightblue')
ax1.set_title('Tip amount distribution')
ax1.set_xlabel('Tip Amount ($)')
ax1.set_ylabel('Counts')
plt.suptitle('')
plt.show()""",'python','Fabric notebook source code'),
 bars('Tip amount distribution',{'x':'Tip Amount ($), approximately 0–25','y':'Counts, 0–900'},'Histogram with 25 bins, heavily right-skewed: most tip amounts are near $0–$3, decreasing rapidly at higher tip amounts. The plot is descriptive; individual bin heights are not used for the answer.')
 ],'The chart is represented as a semantic chart description, not invented numeric bin values.')
query_dax="""EVALUATE
FILTER (
    VALUES ( Customer[Customer Name] ),
    CALCULATE ( COUNTROWS ( 'Order Item' ) ) > 0
)
ORDER BY Customer[Customer Name]"""
add('T1Q107 T1Q108 T1Q109 T1Q118',[code(query_dax,'dax','Original slow DAX query (line 4)')])
add('T1Q138',[table(['Column name','Description'],[
 ['TransactionID','Contains a unique ID for each transaction'],['Date','Contains the date of each transaction'],['ProductID','Contains a unique ID for each product'],['ProductColor','Contains a descriptive attribute that describes the color of each product'],['ProductName','Contains a unique name for each product'],['SalesAmount','Contains the sales amount of each transaction']], 'Lakehouse table columns')])
workspaces=table(['Workspace','Contents'],[
 ['Workspace_DEV','Lakehouse1; Notebook1; Pipeline1; SemanticModel1'],
 ['Workspace_TEST','Lakehouse2; Notebook2; SemanticModel1']], 'Workspaces before deployment')
add('T1Q156 T1Q192',[workspaces])
add('T1Q187',[table(['Name','Data type'],[['MachineId','Int'],['Payload','Dynamic'],['Datetime','Datetime'],['Location','String']], 'Eventstream source columns')])
add('T1Q195',[table(['Table name','Column name','Description'],[
 ['DimAccount','AccountKey','Surrogate key'],['DimAccount','AccountNumber','Business key'],['FactTransaction','Date','Date a transaction occurred'],['FactTransaction','AccountKey','Foreign key to DimAccount'],['FactTransaction','Amount','Amount of each transaction'],['DimCustomer','CustomerKey','Surrogate key'],['DimCustomer','CustomerID','Business key'],['DimCustomer','CustomerName','Customer name']], 'Model tables, columns, and meaning')])
add('T1Q214',[table(['Fiscal Month','Month Number'],[
 ['Jan','1'],['Feb','2'],['Mar','3'],['Apr','4'],['May','5'],['Jun','6'],['Jul','7'],['Aug','8'],['Sep','9'],['Oct','10'],['Nov','11'],['Dec','12']], 'Date table values')])

# T1Q147 has images only in option objects, not exhibits. Rebuild exact SQL options as editable code blocks.
option_code={
'T1Q10':{
 'A':"""SELECT ProductID, ProductName, SUM(Amount) AS TotalAmount
FROM Staging.Sales
WHERE DATEPART(YEAR, SaleDate) = '2023'
GROUP BY ProductID, ProductName
HAVING SUM(Amount) > 10000""",
 'B':"""SELECT ProductID, ProductName, SUM(Amount) AS TotalAmount
FROM Staging.Sales
GROUP BY ProductID, ProductName
HAVING DATEPART(YEAR, SaleDate) = '2023' AND SUM(Amount) > 10000""",
 'C':"""SELECT ProductID, ProductName, SUM(Amount) AS TotalAmount
FROM Staging.Sales
WHERE DATEPART(YEAR, SaleDate) = '2023' AND SUM(Amount) > 10000""",
 'D':"""SELECT ProductID, ProductName, SUM(Amount) AS TotalAmount
FROM Staging.Sales
WHERE DATEPART(YEAR, SaleDate) = '2023'
GROUP BY ProductID, ProductName
HAVING TotalAmount > 10000"""},
'T1Q147':{
 'A':"""SELECT SalesOrderID, ProductID, OrderQty,
 CAST(1. * OrderQty / SUM(OrderQty) OVER(PARTITION BY ProductID) * 100
 AS DECIMAL(5,2)) AS PercentbyProductID
FROM Sales.SalesOrderDetail;""",
 'B':"""SELECT SalesOrderID, ProductID, OrderQty,
 CAST(1. * OrderQty / SUM(OrderQty) OVER(ORDER BY SalesOrderID) * 100
 AS DECIMAL(5,2)) AS PercentbyProductID
FROM Sales.SalesOrderDetail;""",
 'C':"""SELECT SalesOrderID, ProductID, OrderQty,
 CAST(1. * OrderQty / SUM(OrderQty) OVER(ORDER BY ProductID) * 100
 AS DECIMAL(5,2)) AS PercentbyProductID
FROM Sales.SalesOrderDetail;""",
 'D':"""SELECT SalesOrderID, ProductID, OrderQty,
 CAST(1. * OrderQty / SUM(OrderQty) OVER(PARTITION BY SalesOrderID) * 100
 AS DECIMAL(5,2)) AS PercentbyProductID
FROM Sales.SalesOrderDetail;"""}
}
case_visual={
'cs_litware':[
 table(['Description','Original source','Total size'],[
 ['Customer data','Customer relationship management (CRM) system','50 MB'],
 ['Product data','Customer relationship management (CRM) system','200 MB'],
 ['Customer satisfaction surveys','SurveyMonkey','500 GB']], 'Available data, size and source'),
 table(['Name','Data type'],[['ProductID','Integer'],['ProductName','String'],['ProductCategory','String'],['ListPrice','Decimal']], 'Product table columns')]
}

# Auto build an image-free archive; OCR is used only when the source stores key facts in pixels.
new=copy.deepcopy(raw)
new['kind']='dp600-image-free-semantic-question-bank'
new['transform']={'source':'User-supplied Warren-530 index.html and source-export JSON','method':'Source structured controls + manual transcription + Tesseract OCR as review-only fallback','no_raster_media':True,'canonical_question_ids_preserved':True,'ocr_engine':'Tesseract --psm 6 (source embedded PNGs)','qa_policy':'Unverified OCR cannot silently authorize grading; answer images never included as stem evidence.'}
for c in new.get('caseStudies',[]):
 c['sourceVisualReferences']=[x['file'] for x in c.get('images',[])]
 c['semanticVisuals']=case_visual.get(c['id'],[])
 c['visualResolution']='verified_transcription' if c['id'] in case_visual or not c['images'] else 'review_required'
 c['images']=[]

review_rows=[]
for q in new['questions']:
 qid=q['id']; original_ex=q.get('exhibits') or []; originals_ans=q.get('answerImages') or []
 q['sourceVisualReferences']={'exhibits':original_ex,'answerImages':originals_ans,'optionImages':[x.get('image') for x in q.get('options',[]) if x.get('image')]}
 q['semanticVisuals']=[]; q['visualReviewNotes']=[];q['visualOCRDrafts']=[]
 if qid in manual:
  q['semanticVisuals']=manual[qid]['blocks'];q['visualReviewNotes'].append(manual[qid]['note']);state='verified_transcription'
 elif original_ex:
  # No invented precise facts: OCR is reference-only, withheld from canonical examinable prompt until QA.
  valid=[ocr.get(f,{}).get('text','') for f in original_ex]
  usable=[(f,t.strip()) for f,t in zip(original_ex,valid) if t.strip()]
  # Answer widget already encoded; exhibit may carry extra source facts, so require separate QA.
  answer_area_only=all(t.lstrip().lower().startswith('answer area') and len(t)<260 for f,t in usable) and len(usable)==len(original_ex)
  if answer_area_only and q['type'] in ('hotspot-dropdown','hotspot-yesno','dragdrop'):
   state='candidate_interactive_only_review'
   q['visualReviewNotes'].append('The source image appears to show answer controls already represented in structured JSON; a reviewer must still verify that no prompt facts were lost.')
  else:
   state='ocr_review_required'
   q['visualReviewNotes'].append('Exhibit contains potentially essential source facts. OCR transcript below is NOT certified; recover table/code/chart semantically before enabling grading.')
  for f,t in usable:
   q['visualOCRDrafts'].append({'source':f,'transcription':t,'verified':False})
 else:state='no_exhibit_needed'
 if qid in option_code:
  for option in q['options']:
   if option.get('image'):
    option['code']=option_code[qid][option['letter']];option['language']='sql';option.pop('image',None)
  q['visualReviewNotes'].append('Image-only SQL answer options reconstructed as text code blocks.')
 elif any(x.get('image') for x in q.get('options',[])):
  state='ocr_review_required'
  for option in q['options']:
   if option.get('image'):
    name=option.pop('image');option['codeOCRDraft']=ocr.get(name,{}).get('text','')
 if qid in {'T1Q2','T1Q23','T1Q41','T1Q50','T1Q61','T1Q67','T1Q121','T1Q145','T1Q150','T1Q185','T1Q212'} and state=='candidate_interactive_only_review':
  state='structured_answer_area_verified'
  q['visualReviewNotes'].append('Original screenshot contained an answer area; all question labels and selectable answers are encoded in structured blanks/statements and were checked against the source OCR.')
 if qid=='T1Q147':state='verified_transcription'
 # Preserve original references in audit metadata only. No image paths are provided to UI.
 q['exhibits']=[];q['answerImages']=[]
 q['visualResolution']=state
 q['gradingEnabled']=state in ('no_exhibit_needed','verified_transcription','structured_answer_area_verified')
 q['gradedReason']=None if q['gradingEnabled'] else 'The original visual has not passed semantic-content review; scoring is held to prevent grading on an incomplete question.'
 # Include review visibility while not exposing answers in the unanswered UI
 review_rows.append({'id':qid,'type':q['type'],'caseStudy':q.get('caseStudy') or '', 'source_exhibit_count':len(original_ex),'answer_image_count':len(originals_ans),'option_image_count':len(q['sourceVisualReferences']['optionImages']),'visual_resolution':state,'grading_enabled':q['gradingEnabled'],'ocr_drafts':len(q['visualOCRDrafts']),'review_note':' | '.join(q['visualReviewNotes'])[:300]})

# Unique original ID check; no question record dropped.
ids=[q['id'] for q in new['questions']]
assert len(ids)==len(set(ids))==222
assert ids==[q['id'] for q in raw['questions']]
assert all(not q['exhibits'] and not q['answerImages'] and not any(x.get('image') for x in q.get('options',[])) for q in new['questions'])
assert all(not c['images'] for c in new['caseStudies'])
assert new['questions'][0]['answer']==raw['questions'][0]['answer']
assert all(q.get('answer')==r.get('answer') for q,r in zip(new['questions'],raw['questions']))
assert all(q.get('blanks')==r.get('blanks') for q,r in zip(new['questions'],raw['questions']))
assert all(q.get('drag')==r.get('drag') for q,r in zip(new['questions'],raw['questions']))
assert all(q.get('statements')==r.get('statements') for q,r in zip(new['questions'],raw['questions']))

out=W/'dp600-image-free-structured.json';out.write_text(json.dumps(new,ensure_ascii=False,indent=2),'utf-8')
f=W/'visual-review-register.csv'
with f.open('w',encoding='utf-8-sig',newline='') as h:
 wr=csv.DictWriter(h,fieldnames=list(review_rows[0]));wr.writeheader();wr.writerows(review_rows)
counts=dict(collections.Counter(q['visualResolution'] for q in new['questions']))
print('COUNTS',counts,'case studies',[(c['id'],c['visualResolution']) for c in new['caseStudies']]);print('FILE',out,out.stat().st_size)
